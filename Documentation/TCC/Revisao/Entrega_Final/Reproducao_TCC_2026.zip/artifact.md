# Contrato documental

Referência: C:\Users\andre\tcc_revisao\original_comentado.docx
SHA256: 7a2f18b8d35c5f5d05b73a290de6abd1220d4e72632f7f62bb2547b507386fc0

Revisão estrutural autorizada: corpo reorganizado em oito capítulos; capa e folha de rosto preservadas, removida menção a RAG no título. Geometria original preservada: Letter 21,59 x 27,94 cm, margens superior/inferior 2,499 cm, esquerda 3 cm, direita 2 cm. Fonte do corpo Times New Roman12, entrelinha1,5, primeira linha1,25cm. Cabeçalhos pretos12, legendas10. Novos estilos próprios preservam os estilos e partes originais; imagens antigas não são reutilizadas como evidência. Sumário automático requer atualização no Word. Contagem real e verificação visual pendentes por ausência de LibreOffice. O modelo institucional foi consultado; a geometria do documento do autor foi mantida nesta cópia.
