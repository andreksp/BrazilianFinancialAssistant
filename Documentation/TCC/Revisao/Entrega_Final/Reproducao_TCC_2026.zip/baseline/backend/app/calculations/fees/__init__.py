"""Fee and cost calculations."""
