"""Pydantic data models."""
