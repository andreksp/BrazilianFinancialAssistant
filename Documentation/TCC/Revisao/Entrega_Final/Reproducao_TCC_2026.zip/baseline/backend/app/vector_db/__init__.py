"""ChromaDB vector database integration."""
