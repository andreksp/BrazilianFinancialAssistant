from pathlib import Path
import json,hashlib,re,copy
from docx import Document
from docx.shared import Pt,Cm,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.style import WD_STYLE_TYPE
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).parent
SOURCE=ROOT/'original_comentado.docx'
FINAL=ROOT/'Monografia_Revisada_Resultados_2026.docx'
ASSETS=ROOT/'figures';ASSETS.mkdir(exist_ok=True)
summary=json.loads((ROOT/'results_summary.json').read_text(encoding='utf8'))
cases=json.loads((ROOT/'benchmark.json').read_text(encoding='utf8'))
configs=['baseline_sonnet','revised_sonnet','revised_haiku']
labels=['Sonnet / inicial','Sonnet / revisado','Haiku / revisado']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11})
def bar(name,title,labels,values,ylabel,limit):
 fig,ax=plt.subplots(figsize=(7.2,3.5));bars=ax.bar(labels,values,color=['#657786','#245878','#86a6b3'][:len(values)],width=.55)
 ax.set_ylim(0,limit);ax.set_ylabel(ylabel);ax.set_title(title,pad=12);ax.spines[['top','right']].set_visible(False)
 ax.bar_label(bars,labels=[f'{v:.1f}' for v in values],padding=4);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
 fig.tight_layout();fig.savefig(ASSETS/(name+'.png'),dpi=180);plt.close(fig)
bar('answers','Respostas factuais corretas segundo avaliador automático',labels,[summary['configurations'][c]['correct_factual']/42*100 for c in configs],'% de 42 perguntas',100)
bar('calculators','Cenários numéricos com resultado esperado',['Inicial','Revisado'],[6,12],'Casos (n = 12)',14)
fig,ax=plt.subplots(figsize=(7.2,3.5))
for i,(key,label) in enumerate([('baseline_sonnet','Inicial'),('revised_sonnet','Revisado')]):
 vals=[summary['configurations'][key][m]*100 for m in ['p1','p3']]
 bars=ax.bar([x+i*.32 for x in range(2)],vals,width=.30,label=label,color=['#657786','#245878'][i]);ax.bar_label(bars,fmt='%.1f',padding=4)
ax.set_xticks([.16,1.16],['P@1','P@3']);ax.set_ylim(0,100);ax.set_ylabel('% — 42 perguntas factuais');ax.legend();ax.spines[['top','right']].set_visible(False);fig.tight_layout();fig.savefig(ASSETS/'retrieval.png',dpi=180);plt.close(fig)
fig,ax=plt.subplots(figsize=(7.4,5));ax.axis('off')
nodes={'ui':(.10,.86,'Interface Angular'),'api':(.49,.86,'API FastAPI'),'agent':(.49,.61,'Orquestração e agentes'),
 'calc':(.10,.34,'Calculadoras\n(funções Python)'),'rag':(.49,.34,'Recuperação\nChromaDB'),
 'llm':(.88,.34,'API do modelo\ninterpretação / texto'),'db':(.10,.09,'Persistência\nrelacional'),
 'mcp':(.79,.09,'Servidor MCP separado\nintegração não demonstrada')}
for k,(x,y,label) in nodes.items():ax.text(x,y,label,ha='center',va='center',fontsize=9,bbox=dict(boxstyle='round,pad=.55',fc='#edf2f4',ec='#36576b'),transform=ax.transAxes)
for a,b in [('ui','api'),('api','agent'),('agent','calc'),('agent','rag'),('agent','llm'),('agent','db')]:
 x,y,_=nodes[a];xx,yy,_=nodes[b];ax.annotate('',xy=(xx,yy+.045),xytext=(x,y-.055),xycoords='axes fraction',arrowprops=dict(arrowstyle='->',color='#36576b',shrinkA=12,shrinkB=12))
fig.tight_layout();fig.savefig(ASSETS/'architecture.png',dpi=180,bbox_inches='tight');plt.close(fig)

doc=Document(SOURCE)
# Preserve source cover and title page, section geometry, styles and package assets.
body=doc._element.body
first=next(p for p in doc.paragraphs if p.text.strip()=='RESUMO')._p
remove=False
for el in list(body):
 if el is first:remove=True
 if remove and el.tag!=qn('w:sectPr'):body.remove(el)
for p in doc.paragraphs:
 if 'BASEADO EM RAG' in p.text:p.text=p.text.replace(' BASEADO EM RAG','')
 if p.text.strip() in ('São Paulo','2026'):p.alignment=WD_ALIGN_PARAGRAPH.CENTER
for name,size,bold in [('TCC Corpo',12,False),('TCC Capitulo',12,True),('TCC Preliminar',12,True),('TCC Secao',12,True),('TCC Legenda',10,False),('TCC Referencia',10,False)]:
 st=doc.styles.add_style(name,WD_STYLE_TYPE.PARAGRAPH) if name not in doc.styles else doc.styles[name]
 st.font.name='Times New Roman';st.font.size=Pt(size);st.font.bold=bold;st.font.color.rgb=RGBColor(0,0,0)
 pf=st.paragraph_format;pf.space_after=Pt(6);pf.line_spacing=1.5 if name=='TCC Corpo' else 1.0
 pf.first_line_indent=Cm(1.25) if name=='TCC Corpo' else Cm(0)
 pf.widow_control=True;pf.keep_with_next=name in ('TCC Capitulo','TCC Secao','TCC Legenda')
 if name in ('TCC Capitulo','TCC Secao'):
  pf.space_before=Pt(18);pf.space_after=Pt(12)
  outline=OxmlElement('w:outlineLvl');outline.set(qn('w:val'),'0' if name=='TCC Capitulo' else '1');st.element.get_or_add_pPr().append(outline)
 if name in ('TCC Capitulo','TCC Preliminar'):pf.page_break_before=True
def p(text,style='TCC Corpo'):
 pp=doc.add_paragraph(text,style);pp.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY if style=='TCC Corpo' else WD_ALIGN_PARAGRAPH.LEFT;return pp
def heading(text,level=1):return p(text,'TCC Preliminar' if text in ('RESUMO','ABSTRACT','SUMÁRIO') else ('TCC Capitulo' if level==1 else 'TCC Secao'))
def table(headers,rows):
 t=doc.add_table(rows=1,cols=len(headers));t.autofit=False
 usable=doc.sections[-1].page_width-doc.sections[-1].left_margin-doc.sections[-1].right_margin
 width=int(usable/635/len(headers));total=width*len(headers)
 pr=t._tbl.tblPr
 tw=pr.find(qn('w:tblW'));tw.set(qn('w:type'),'dxa');tw.set(qn('w:w'),str(total))
 ind=OxmlElement('w:tblInd');ind.set(qn('w:type'),'dxa');ind.set(qn('w:w'),'120');pr.append(ind)
 for col in t._tbl.tblGrid:col.set(qn('w:w'),str(width))
 for cell,text in zip(t.rows[0].cells,headers):cell.text=text
 for row in rows:
  for cell,text in zip(t.add_row().cells,row):cell.text=str(text)
 for n,row in enumerate(t.rows):
  if n==0:
   repeat=OxmlElement('w:tblHeader');row._tr.get_or_add_trPr().append(repeat)
  for cell in row.cells:
   cell.width=Cm(width/567)
   cell._tc.get_or_add_tcPr().find(qn('w:tcW')).set(qn('w:w'),str(width))
   for pp in cell.paragraphs:
    pp.style=doc.styles['TCC Referencia'];pp.paragraph_format.space_after=Pt(5)
    for r in pp.runs:r.bold=n==0
 return t
fig_number=0
def figure(name):
 global fig_number
 fig_number+=1
 titles={'architecture':'Arquitetura consolidada e limites da integração','answers':'Correção factual segundo avaliação automática',
 'retrieval':'Precisão dos primeiros resultados recuperados','calculators':'Verificação dos cenários numéricos'}
 p(f'Figura {fig_number} – {titles[name]}','TCC Legenda')
 pp=doc.add_paragraph();pp.alignment=WD_ALIGN_PARAGRAPH.CENTER
 inline=pp.add_run().add_picture(str(ASSETS/(name+'.png')),width=Cm(15))
 inline._inline.docPr.set('descr',titles[name])
 p('Fonte: elaboração própria a partir do código e dos registros experimentais (2026).','TCC Referencia')

SCREENSHOTS=[
 ('screenshots/screenshot_fii.jpg','Venda de FII pela interface — sucesso','Interface Angular conectada ao backend revisado, dados sintéticos, sessão de 2026-09-13.'),
 ('screenshots/screenshot_doador.jpg','Remuneração do doador pela interface — sucesso','Interface Angular conectada ao backend revisado, dados sintéticos, sessão de 2026-09-13.'),
 ('screenshots/screenshot_chat_fii.jpg','Chat em linguagem natural sobre FII — resposta real','Interface Angular conectada ao backend revisado; única chamada nova à API do modelo nesta revisão, autorizada pelo usuário, sessão de 2026-09-13.'),
 ('screenshots/screenshot_acao_falha.jpg','Venda de ações pela interface — recusa real por campo ausente no formulário','Interface Angular conectada ao backend revisado, sessão de 2026-09-13. Evidencia a lacuna descrita no texto, não um erro de captura.'),
 ('screenshots/screenshot_win_falha.jpg','Futuro WIN pela interface — recusa real por campo ausente no formulário','Interface Angular conectada ao backend revisado, sessão de 2026-09-13. Evidencia a lacuna descrita no texto, não um erro de captura.'),
]
def screenshot_figure(path,title,source):
 global fig_number
 fig_number+=1
 p(f'Figura {fig_number} – {title}','TCC Legenda')
 pp=doc.add_paragraph();pp.alignment=WD_ALIGN_PARAGRAPH.CENTER
 inline=pp.add_run().add_picture(str(ASSETS/path),width=Cm(14))
 inline._inline.docPr.set('descr',title)
 p(f'Fonte: {source}','TCC Referencia')

heading('RESUMO')
p('Este trabalho apresenta e avalia um protótipo de assistente para apoio à tributação de investimentos no mercado financeiro brasileiro. A solução combina recuperação de evidências, modelos de linguagem e calculadoras determinísticas, abrangendo consultas sobre ações, BDRs, fundos imobiliários, opções, futuros, empréstimo de ações e criptoativos. A pesquisa aplicada compara configurações inicial e revisada em benchmark sintético de 60 perguntas, das quais 48 integram o teste. A avaliação automática separa relevância da recuperação, correção das respostas, fundamentação e abstenção. Nas 42 perguntas factuais, o Sonnet com contexto revisado apresentou 37 respostas consideradas corretas, contra 29 com contexto inicial; o Haiku com contexto revisado apresentou 30. A precisão no primeiro resultado recuperado passou de 52,4% para 57,1%. Em 12 cenários numéricos, os resultados esperados foram atendidos em seis casos na versão inicial e nos 12 na revisada. O julgamento repetido manteve 32 de 36 notas de correção. Os resultados indicam benefício da revisão no conjunto examinado, sem demonstrar correção fiscal geral. As principais limitações são o pequeno corpus, gabaritos assistidos por IA, ausência de validação tributária independente, simplificações do motor e avaliação não integral do fluxo de interface. A contribuição é tornar verificável a relação entre pergunta, fonte, resposta e cálculo.')
p('Palavras-chave: inteligência artificial; recuperação de informação; tributação; mercado financeiro; avaliação de sistemas.','TCC Referencia')
heading('ABSTRACT')
p('This work presents and evaluates a prototype assistant supporting investment taxation questions in the Brazilian financial market. The system combines evidence retrieval, language models, and deterministic calculators, covering stocks, BDRs, real estate funds, options, futures, securities lending, and cryptoassets. This applied study compares initial and revised configurations using a synthetic benchmark of 60 questions, including 48 test cases. Automatic evaluation separates retrieval relevance, answer correctness, grounding, and abstention. Among 42 factual questions, Sonnet with revised context obtained 37 answers rated correct, compared with 29 using initial context; Haiku with revised context obtained 30. Precision at the first retrieved result increased from 52.4% to 57.1%. In 12 numerical scenarios, expected results were met in six initial-version cases and all revised-version cases. Repeated judging preserved 32 of 36 correctness grades. These findings support a limited benefit within the examined dataset, not general tax accuracy. Limitations include a small corpus, AI-assisted reference answers, lack of independent tax-expert validation, simplified calculations, and incomplete end-to-end interface evaluation. The contribution is a traceable relationship among questions, sources, answers, and calculations.')
p('Keywords: artificial intelligence; information retrieval; taxation; financial market; system evaluation.','TCC Referencia')
heading('SUMÁRIO')
toc=doc.add_paragraph()
field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'TOC \\h \\z \\t "TCC Capitulo,1,TCC Secao,2"');toc._p.append(field)
# Cached readable headings inside the field, replaced (not duplicated) on update.
for line in (ROOT/'manuscrito.md').read_text(encoding='utf8').splitlines():
 if line.startswith('# ') or line.startswith('## '):
  run=OxmlElement('w:r');txt=OxmlElement('w:t');txt.text=line.lstrip('# ');run.append(txt);run.append(OxmlElement('w:br'));field.append(run)
for line in (ROOT/'manuscrito.md').read_text(encoding='utf8').splitlines():
 if not line.strip():continue
 if line.startswith('# '):heading(line[2:])
 elif line.startswith('## '):heading(line[3:],2)
 elif line.startswith('[[FIG:'):figure(line[6:-2])
 elif line=='[[SCREENSHOTS]]':
  for path,title,source in SCREENSHOTS:screenshot_figure(path,title,source)
 elif line=='[[TABLE:routes]]':
  p('Tabela 1 – Principais interfaces HTTP inspecionadas','TCC Legenda')
  table(['Método / rota','Finalidade'],[['POST /api/chat/','Mensagem conversacional'],['GET /api/chat/history','Histórico de mensagens'],['POST /api/trades/process','Operação estruturada'],['POST /api/trades/batch','Processamento de lote'],['GET /api/trades/history','Histórico de resultados'],['GET /api/calculations/summary','Resumo mensal'],['GET /api/calculations/darf','Informações de recolhimento']])
 elif line=='[[TABLE:answers]]':
  p('Tabela 2 – Correção factual e erros críticos','TCC Legenda')
  table(['Configuração','Corretas / 42','Erros críticos / 48'],[[label,str(summary['configurations'][c]['correct_factual']),str(summary['configurations'][c]['critical_errors'])] for c,label in zip(configs,labels)])
 elif line=='[[TABLE:retrieval]]':
  p('Tabela 3 – Recuperação: 42 perguntas factuais','TCC Legenda')
  table(['Contexto','P@1','P@3','nDCG@3 agrupada'],[[label,*[f"{summary['configurations'][key][m]:.3f}" for m in ['p1','p3','ndcg3_pooled']]] for key,label in [('baseline_sonnet','Inicial'),('revised_sonnet','Revisado')]])
 elif line=='[[TABLE:calculators]]':
  p('Tabela 4 – Verificação numérica antes e depois','TCC Legenda')
  initial=json.loads((ROOT/'baseline_calculator_checks.json').read_text(encoding='utf8'));revised=json.loads((ROOT/'revised_calculator_checks.json').read_text(encoding='utf8'))
  table(['Cenário','Inicial','Revisado'],[[a['id'],'Atendeu' if a['passed'] else 'Não atendeu','Atendeu' if b['passed'] else 'Não atendeu'] for a,b in zip(initial,revised)])
 elif line=='[[EXAMPLES]]':
  for cid in ['T13','T01','T37','T25','T31']:
   case=next(c for c in cases if c['id']==cid)
   answer=json.loads((ROOT/'api_results'/(cid+'_revised_sonnet.json')).read_text(encoding='utf8'))['text']
   heading(f"Exemplo {cid} – {case['domain']}",2);p('Pergunta: '+case['question'])
   for para in answer.split('\n\n'):
    text=re.sub(r'\*\*|^#+\s*','',para).replace('\n',' ')
    p(text,'TCC Referencia')
   p('Fonte: saída registrada da configuração Sonnet/revisado. Transcrição do experimento; não é captura de interface.','TCC Referencia')
 else:p(line)

heading('REFERÊNCIAS')
refs=[
('MALKOV, Yu. A.; YASHUNIN, D. A. Efficient and robust approximate nearest neighbor search using Hierarchical Navigable Small World graphs. 2016.','https://arxiv.org/abs/1603.09320'),
('VASWANI, Ashish et al. Attention Is All You Need. 2017.','https://arxiv.org/abs/1706.03762'),
('B3. 2026a. Empréstimo de ativos: informações.','https://www.b3.com.br/pt_br/produtos-e-servicos/emprestimo-de-ativos/informacoes.htm'),
('B3. 2026b. Como declarar BDRs no Imposto de Renda 2026. Bora Investir.','https://borainvestir.b3.com.br/noticias/imposto-de-renda/renda-variavel-imposto-de-renda/como-declarar-bdrs-no-imposto-de-renda-2026-veja-guia-completo-para-nao-cometer-erros/'),
('B3. 2026c. Futuro Mini de Ibovespa.','https://www.b3.com.br/pt_br/produtos-e-servicos/negociacao/renda-variavel/futuro-mini-de-ibovespa.htm'),
('B3. 2026d. Futuro Míni de Taxa de Câmbio de Reais por Dólar Comercial.','https://www.b3.com.br/pt_br/produtos-e-servicos/negociacao/moedas/futuro-mini-de-taxa-de-cambio-de-reais-por-dolar-comercial.htm'),
('B3. Pessoas Físicas: uma análise da evolução dos investidores na B3 — 2º trimestre de 2025.','https://www.b3.com.br/data/files/A2/A0/78/20/E61689100A29E189AC094EA8/Book%20PF%202TRI%202025_vF.pdf'),
('BENDER, Emily M. et al. On the Dangers of Stochastic Parrots: Can Language Models Be Too Big? FAccT, 2021.','https://dl.acm.org/doi/10.1145/3442188.3445922'),
('BROWN, Tom B. et al. Language Models are Few-Shot Learners. NeurIPS, 2020.','https://arxiv.org/abs/2005.14165'),
('BRASIL. Lei nº 11.033, de 21 de dezembro de 2004. Texto consolidado.','https://www.planalto.gov.br/ccivil_03/_ato2004-2006/2004/lei/l11033.htm'),
('BRASIL. Lei nº 13.259, de 16 de março de 2016.','https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2016/lei/l13259.htm'),
('BRASIL. Lei nº 14.754, de 12 de dezembro de 2023.','https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2023/lei/l14754.htm'),
('BRASIL. Lei nº 15.265, de 21 de novembro de 2025.','https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2025/lei/l15265.htm'),
('LEWIS, Patrick et al. Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks. NeurIPS, 2020.','https://arxiv.org/abs/2005.11401'),
('MODEL CONTEXT PROTOCOL. Tools: specification. 2026.','https://modelcontextprotocol.io/specification/draft/server/tools'),
('RECEITA FEDERAL. Instrução Normativa RFB nº 1.585, de 31 de agosto de 2015.','https://normas.receita.fazenda.gov.br/sijut2consulta/link.action?idAto=67494'),
('RECEITA FEDERAL. Solução de Consulta Cosit nº 214, de 20 de dezembro de 2021.','https://normas.receita.fazenda.gov.br/sijut2consulta/anexoOutros.action?idArquivoBinario=64040'),
('RECEITA FEDERAL. 2026a. Isenções: bolsa de valores.','https://www.gov.br/receitafederal/pt-br/assuntos/meu-imposto-de-renda/pagamento/renda-variavel/bolsa-de-valores-1/isencoes'),
('RECEITA FEDERAL. 2026b. Fundos de Investimento no Brasil.','https://www.gov.br/receitafederal/pt-br/assuntos/meu-imposto-de-renda/pagamento/renda-variavel/fundos-de-investimento-no-brasil'),
('RECEITA FEDERAL. 2026c. Compensações: bolsa de valores.','https://www.gov.br/receitafederal/pt-br/assuntos/meu-imposto-de-renda/pagamento/renda-variavel/bolsa-de-valores-1/compensacoes'),
('REIMERS, Nils; GUREVYCH, Iryna. Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks. EMNLP-IJCNLP, 2019.','https://aclanthology.org/D19-1410/'),
('ZHENG, Lianmin et al. Judging LLM-as-a-Judge with MT-Bench and Chatbot Arena. 2023.','https://arxiv.org/abs/2306.05685'),
('ANTHROPIC. Pricing: Claude Platform Docs. 2026.','https://platform.claude.com/docs/en/about-claude/pricing')]
for label,url in sorted(refs):p(f'{label} Disponível em: {url}. Acesso em: 12 set. 2026.','TCC Referencia')
heading('APÊNDICE A – BENCHMARK E FATOS ESPERADOS')
p('As perguntas seguintes são sintéticas. Os gabaritos são fatos esperados preparados com assistência de IA, não pareceres de especialista. A data de referência é 12/09/2026. A reprodução integral está em benchmark.json. As perguntas de desenvolvimento não integram os escores finais.')
for c in cases:
 pp=p(f"{c['id']} | {c['domain']} | {'Teste' if c['split']=='test' else 'Desenvolvimento'}",'TCC Secao')
 p(c['question'])
 p('Fatos esperados: '+c['gold'],'TCC Referencia')
 if c['sources']:p('Referência: '+c['sources'][0],'TCC Referencia')
heading('APÊNDICE B – REPRODUÇÃO E USO DE IA')
p('O código inicial foi desenvolvido com assistência do Claude, conforme informação do autor. A revisão documental, a preparação do benchmark e as alterações experimentais receberam assistência de IA. As respostas de teste foram produzidas por modelos Anthropic e avaliadas automaticamente por outro modelo da mesma família. Não houve revisão humana especializada dos rótulos nesta execução. O autor deve conferir as referências, validar as afirmações e observar as exigências institucionais para declaração de uso dessas ferramentas.')
p('A pasta de reprodução contém snapshot.json, benchmark.json, os arquivos de recuperação das duas versões, api_results, api_ledger.jsonl, results_summary.json, results_per_case.csv e os resultados das calculadoras. Os scripts preservam respostas concluídas para evitar nova cobrança ao retomar uma execução. A chave de API não integra os arquivos de resultados.')
p('Sequência de reprodução: verificar as dependências locais e a credencial; executar retrieve.py; executar experiment.py; executar judge.py; executar aggregate.py; executar calculator_checks.py. O benchmark congelado e o manifesto de versões devem ser preservados. Alterações posteriores de integração e novos testes de segurança devem ser distinguidos da configuração usada no experimento de recuperação e geração.')
p('Pendências para submissão: validar conteúdo com o orientador e especialista tributário; inserir capturas de tela reais da interface Angular após conexão de navegador (nesta revisão, os cenários estruturados foram executados contra um servidor real via API, não via navegador). A migração dos testes legados foi concluída nesta revisão (88 testes aprovados, ver Seção 6.5) e a paginação foi conferida por renderização real em Word (ver Seção de verificação visual). Não foram fabricadas capturas nem números de páginas.')
settings=doc.settings.element
update=settings.find(qn('w:updateFields'))
if update is None:update=OxmlElement('w:updateFields');settings.append(update)
update.set(qn('w:val'),'true')
doc.core_properties.title='Assistente inteligente para apoio em tributação e regulação no mercado financeiro brasileiro'
doc.core_properties.author='Andre Khenaifes'
doc.core_properties.subject='Monografia revisada com resultados experimentais e limitações'
doc.save(FINAL)
audit=dict(source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),output=str(FINAL),
 words=len(' '.join(p.text for p in doc.paragraphs).split()),figures=len(doc.inline_shapes),tables=len(doc.tables),
 chapters=[p.text for p in doc.paragraphs if p.style.name=='TCC Capitulo'],page_count=None,
 visual_qa='Pending renderer; page count not inferred from page breaks',reference_count=len(refs))
(ROOT/'document_structure_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf8')
(ROOT/'artifact.md').write_text('# Contrato documental\n\nReferência: '+str(SOURCE)+'\nSHA256: '+audit['source_sha256']+
 '\n\nRevisão estrutural autorizada: corpo reorganizado em oito capítulos; capa e folha de rosto preservadas, removida menção a RAG no título. Geometria original preservada: Letter 21,59 x 27,94 cm, margens superior/inferior 2,499 cm, esquerda 3 cm, direita 2 cm. Fonte do corpo Times New Roman12, entrelinha1,5, primeira linha1,25cm. Cabeçalhos pretos12, legendas10. Novos estilos próprios preservam os estilos e partes originais; imagens antigas não são reutilizadas como evidência. Sumário automático requer atualização no Word. Contagem real e verificação visual pendentes por ausência de LibreOffice. O modelo institucional foi consultado; a geometria do documento do autor foi mantida nesta cópia.\n',encoding='utf8')
print(json.dumps(audit,ensure_ascii=False,indent=2))
