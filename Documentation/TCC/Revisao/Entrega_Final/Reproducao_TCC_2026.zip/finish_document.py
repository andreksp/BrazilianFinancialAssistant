"""Finalize comments, links and reproducibility records without changing source."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from lxml import etree
import json,csv,subprocess,sys,re,hashlib
ROOT=Path(__file__).parent
SKILL=Path(r'C:\Users\andre\.codex\plugins\cache\openai-primary-runtime\documents\26.819.11345\skills\documents')
FINAL=ROOT/'Monografia_Revisada_para_Orientador.docx'
subprocess.run([sys.executable,str(SKILL/'scripts/comments_strip.py'),str(ROOT/'Monografia_Revisada_Resultados_2026.docx'),'--out',str(FINAL)],check=True)
comments=json.loads((ROOT/'comments.json').read_text(encoding='utf8'))
groups={
 'Cap. 1 – Introdução':set(range(9,20)),
 'Cap. 2 – Fundamentação':set(range(20,31)),
 'Cap. 5 – Arquitetura':set(range(31,41))|{59,65,66,67,68,69,74,75,76,81,83,110,112,113,120},
 'Cap. 6/7 – Método e resultados':{42,43,44,45,49,51,52,53,54,70,71,73,92,123},
 'Cap. 8 – Conclusão':{46,47,48,58,64,85,86,88,89,90,91,94,95,96,100,121,122},
 'Cap. 4 – Trabalhos relacionados':{60,61,62,63},
 'Cap. 3 – Domínio brasileiro':{105,106,107,108,109,111,114,115},
 'Figuras no corpo':{34,116,117,118,119},
 'Elementos iniciais':set(range(9)),
 'Conteúdo redundante removido ou condensado':{50,55,56,57,72,77,78,79,80,82,84,87,93,97,98,99,101,102,103,104},
}
records=[]
for c in comments:
 i=int(c['id']);target=next((k for k,v in groups.items() if i in v),'Revisão textual do corpo')
 status='Tratado na reestruturação; conferir com orientador'
 note='Encaminhamento editorial; não significa aprovação do orientador.'
 if i in {41,123}:status='Parcial';note='Há transcrições reais e resultados; capturas de interface dependem de navegador conectado.'
 if i in {9,60,61}:status='Parcial';note='Contexto e referências primárias ampliados; faltam estatísticas de mercado e comparação ampliada de sistemas similares.'
 if i in {105,106,114}:status='Alternativa por solicitação do autor';note='Domínio B3 e tributário reunido em capítulo próprio, com cripto em seção distinta.'
 if i in {33,39,68}:status='Descrição corrigida conforme código';note='MCP separado; não se atribui integração inexistente. Centralização futura não implementada.'
 if i==8:status='Parcial';note='Sumário com capítulos e subseções; atualização de campos e páginas exige Word.'
 if i==23:note='Conceitos ampliados; não se classificaram GPT/Gemini/Claude como modelos abertos.'
 records.append(dict(id=i,comentario=c['comment'],ancora=' | '.join(c['anchors']),destino=target,status=status,observacao=note))
with (ROOT/'matriz_comentarios.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(sorted(records,key=lambda r:r['id']))
with ZipFile(FINAL) as z:
 root=etree.fromstring(z.read('word/document.xml'))
 ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','a':'http://schemas.openxmlformats.org/drawingml/2006/main'}
 text=' '.join(root.xpath('//w:t/text()',namespaces=ns))
 assert '[[FIG:' not in text and '[[TABLE:' not in text and '[[SCREENSHOTS]]' not in text
 assert 'word/comments.xml' not in z.namelist()
 assert len(root.xpath('//w:tbl',namespaces=ns))==4
 assert text.count('APÊNDICE A – BENCHMARK E FATOS ESPERADOS')==1
 figure_count=len(root.xpath('//a:blip',namespaces=ns))
 report=dict(file=str(FINAL),sha256=hashlib.sha256(FINAL.read_bytes()).hexdigest(),
  original_sha256=hashlib.sha256((ROOT/'original_comentado.docx').read_bytes()).hexdigest(),
  comments_removed=True,figures=figure_count,tables=4,word_count=len(text.split()),
  render_status='Blocked: LibreOffice/soffice executable missing; pdf2image installed.',
  page_count=None,interface_screenshots='Pending actual browser connection',professor_comments=len(records))
 (ROOT/'final_document_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
# Only experiment materials and copied code; no credentials or databases.
with ZipFile(ROOT/'Reproducao_TCC_2026.zip','w',ZIP_DEFLATED) as z:
 for path in ROOT.iterdir():
  if path.suffix in {'.py','.json','.jsonl','.csv','.sha256','.md'}:z.write(path,path.name)
 for directory in ['api_results','figures','baseline','revised']:
  for path in (ROOT/directory).rglob('*'):
   if path.is_file() and not any(x in path.parts for x in ['__pycache__','node_modules','.pytest_cache']) and path.name!='.env' and path.suffix not in {'.db','.pyc'}:
    z.write(path,path.relative_to(ROOT))
print(json.dumps(report,ensure_ascii=False,indent=2))
