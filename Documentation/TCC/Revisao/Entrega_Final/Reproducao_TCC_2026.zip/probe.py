from pathlib import Path
import json
from dotenv import dotenv_values
from anthropic import Anthropic
cfg=dotenv_values(r'D:\Projects\BrazilianFinancialAssistant\backend\.env')
client=Anthropic(api_key=cfg.get('ANTHROPIC_API_KEY'),timeout=30,max_retries=0)
try:
    models=[{'id':m.id,'name':m.display_name} for m in client.models.list(limit=100).data]
    print(json.dumps(models))
    Path(__file__).with_name('available_models.json').write_text(json.dumps(models,indent=2))
except Exception as e:
    print(type(e).__name__,str(e)[:300])
    raise SystemExit(1)
