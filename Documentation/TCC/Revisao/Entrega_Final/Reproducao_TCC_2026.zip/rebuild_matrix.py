# -*- coding: utf-8 -*-
"""Rebuild matriz_comentarios.csv with verified Atendido/Parcial/Pendente status,
cross-checked against the current manuscrito.md content (not just the restructuring
heuristic used on the first pass). Run manually after each manuscrito.md content pass.
"""
import json, csv
from pathlib import Path
from collections import Counter

ROOT = Path(__file__).parent
comments = json.loads((ROOT / 'comments.json').read_text(encoding='utf-8'))

# Same destino grouping used originally by finish_document.py (kept for continuity).
groups = {
    'Cap. 1 - Introducao': set(range(9, 20)),
    'Cap. 2 - Fundamentacao': set(range(20, 31)),
    'Cap. 5 - Arquitetura': set(range(31, 41)) | {59, 65, 66, 67, 68, 69, 74, 75, 76, 81, 83, 110, 112, 113, 120},
    'Cap. 6/7 - Metodo e resultados': {42, 43, 44, 45, 49, 51, 52, 53, 54, 70, 71, 73, 92, 123},
    'Cap. 8 - Conclusao': {46, 47, 48, 58, 64, 85, 86, 88, 89, 90, 91, 94, 95, 96, 100, 121, 122},
    'Cap. 4 - Trabalhos relacionados': {60, 61, 62, 63},
    'Cap. 3 - Dominio brasileiro': {105, 106, 107, 108, 109, 111, 114, 115},
    'Figuras no corpo': {34, 116, 117, 118, 119},
    'Elementos iniciais': set(range(9)),
    'Conteudo redundante removido ou condensado': {50, 55, 56, 57, 72, 77, 78, 79, 80, 82, 84, 87, 93, 97, 98, 99, 101, 102, 103, 104},
}

# ---- Verified against the current manuscrito.md text (revision pass 2026-09-13) ----

PENDENTE = {
    111: 'Extracao assistida de documentos (upload de nota, extracao de campos com confirmacao do usuario) nao aparece nem no corpo nem em Trabalhos Futuros.',
}

PARCIAL = {
    60: 'Referencias reais e verificaveis foram incluidas no capitulo (Lewis et al., Reimers e Gurevych, Zheng et al.).',
    61: 'O capitulo discute os metodos (RAG, embeddings, avaliacao por LLM) com referencias primarias, mas nao traz o paragrafo de "sistemas comparaveis" (o que o sistema X propoe, o que usa, principal resultado) pedido pelo comentario - nao foram localizados estudos aplicados de RAG tributario brasileiro verificaveis no prazo desta revisao.',
    8: 'Sumario automatico (campo TOC) inclui titulos de capitulo e de secao; atualizacao de campos e renumeracao de pagina ainda depende de abrir o arquivo no Word (F9 / atualizar sumario) - a renderizacao feita nesta revisao confirma que o campo existe, mas a atualizacao final deve ser conferida no Word do autor.',
    23: 'Estrutura solicitada (contextualizacao, Transformer, treinamento, familias de modelo, alucinacao) foi seguida; a citacao a Bender et al. (2021), presente no texto anterior, nao foi mantida no capitulo revisado - o ponto (desatualizacao/alucinacao) permanece, mas sem essa referencia especifica.',
    24: 'Fluxo RAG e chunking sao discutidos em texto (Secao 2.3) e a Figura 1 cobre a arquitetura consolidada, mas nao existe um diagrama dedicado ao pipeline de RAG (consulta -> embedding -> busca -> contexto -> geracao) como sugerido.',
    33: 'Backend, RAG e MCP sao detalhados com profundidade (Secoes 5.1-5.6, incluindo modelo de embeddings, k=3, distancia de cosseno); nao ha secao dedicada ao frontend Angular no mesmo nivel de detalhe.',
    35: 'Responsabilidades sao descritas por camada (Secao 5.1) e por interface (5.2), mas nao como uma secao isolada por modulo de codigo.',
    38: 'Todas as perguntas da reestruturacao (fontes, chunking, modelo de embeddings e justificativa, base vetorial, algoritmo aproximado, k, limiar de similaridade) sao respondidas no texto (Secao 5.3), inclusive quando a resposta e "nao foi calibrado"; mantido como parcial apenas porque nenhum k alternativo a 3 foi testado ou comparado.',
    41: 'Capturas de tela reais da interface Angular foram obtidas nesta revisao (usuario ativou o Claude in Chrome durante a sessao): FII e emprestimo de acoes funcionam ponta a ponta pela interface; acoes e futuros WIN falham pela interface com a mensagem real do backend, porque o formulario nunca foi atualizado para os novos campos obrigatorios (total_vendas_mes, custos_operacao, irrf_informado) - um gap de integracao que so foi descoberto por nao ter sido testado antes. Uma pergunta real em linguagem natural sobre FII tambem foi capturada no chat (1 nova chamada paga, autorizada pelo usuario). As 5 capturas foram incorporadas ao corpo do documento como Figuras 5-9 (Secao 7.4); os arquivos originais tambem ficam em evidencias/screenshots_interface_real/. Mantido como Parcial porque nem todos os tipos de ativo foram exercitados pela interface (ex.: BDR, opcao, cripto).',
    64: 'O capitulo de evolucao foi condensado; itens gerais (avaliacao de ponta a ponta, especialista, agregacao mensal) aparecem em Trabalhos Futuros, mas parte do conteudo original (versionamento, crescimento de corpus) nao e individualmente citada.',
    69: 'O principio geral (validacao sintatica nao e validacao tributaria) e afirmado na Secao 5.2, mas o fluxo especifico de "confirmar dados extraidos com o usuario antes de calcular" nao e detalhado como processo.',
    85: 'Necessidade de rastrear posicao/eventos corporativos e mencionada de forma geral (persistencia, Secao 5.5); nao aparece como item especifico em Trabalhos Futuros.',
    88: 'Risco de injecao de prompt nao e mencionado no corpo nem em Trabalhos Futuros nesta versao.',
    94: 'Estrategia de fallback nao aparece como item especifico em Trabalhos Futuros (apenas o comportamento de recusa por dados ausentes e tratado, que e um conceito relacionado, nao o mesmo).',
    95: 'Observabilidade operacional nao aparece como item especifico em Trabalhos Futuros.',
    96: 'Gestao de configuracao nao aparece como item especifico em Trabalhos Futuros.',
    100: 'Explicabilidade e uma consequencia do desenho (separacao calculo/RAG/LLM, Capitulo 5), mas nao e citada nominalmente em Trabalhos Futuros.',
123: 'Capitulo de resultados agora existe e separa avaliacao objetiva (Secoes 7.1-7.3) de demonstracao do sistema (Secao 7.4); a demonstracao inclui, nesta revisao, execucao real via API, transcricoes ja registradas e 5 capturas de tela reais da interface incorporadas ao corpo do documento como Figuras 5-9 (ver comentario 41). Mantido como Parcial apenas porque nao ha estudo de usabilidade com usuarios reais, o que o comentario original nao exigia mas o texto do capitulo declara explicitamente como fora do escopo.',
}

ALTERNATIVA = {
    105: 'Dominio B3 e tributario reunido em capitulo proprio (Capitulo 3), com criptoativos em secao distinta (3.6), em vez de encaixado na antiga Secao 2.5 - alternativa estrutural equivalente.',
    106: 'Conteudo da B3 mantido em subsecoes tematicas dentro do Capitulo 3, nao em secao unica sem subdivisoes - alternativa estrutural equivalente.',
    114: 'Curadoria normativa tratada na Secao 3.7 (capitulo de dominio), nao movida para uma antiga "Secao 2.5" que nao existe na estrutura revisada.',
}
ATENDIDO_ESPECIFICO = {
    9: 'Adicionado na Secao 1.1 um paragrafo com numero real e verificavel: 5,4 milhoes de investidores pessoa fisica em renda variavel e R$588,3 bilhoes investidos no 2o trimestre de 2025, fonte primaria B3 (2025) - relatorio "Pessoas Fisicas: uma analise da evolucao dos investidores na B3". A comparacao ampliada de sistemas similares (pedida no mesmo comentario mas voltada ao Capitulo 4) permanece parcial - ver comentario 61.',
    10: 'O trecho equivalente hoje esta na Secao 2.1 (moveu do Capitulo 1 na reestruturacao). Adicionada referencia BROWN et al. (2020) para o volume de pre-treinamento dos modelos de linguagem.',
    11: 'Mesmo trecho da Secao 2.1: adicionada BROWN et al. (2020) para "bilhoes de documentos" e BENDER et al. (2021) para o risco de alucinacao/desatualizacao - a segunda referencia ja existia na versao original e havia sido perdida na reestruturacao.',
    18: 'Objetivos especificos da Secao 1.2 reescritos como itens a)-e) em linhas separadas, em vez de uma unica frase com "; ".',
    19: 'Secao 1.3 reescrita em voz passiva ("Nos capitulos seguintes sao apresentados...") seguindo o exemplo dado pelo comentario.',
}

DESCRICAO_CORRIGIDA = {
    39: 'Secao 5.6 responde diretamente: as capacidades do servidor MCP existem no repositorio, mas o calculo de impostos e chamado diretamente pelo backend, nao pelo MCP - descrito conforme o codigo, nao conforme a sugestao original.',
    68: 'Secao 5.6 responde diretamente: os prompts e chamadas as calculadoras permanecem no backend; centralizar no MCP e citado como alternativa futura, nao como implementacao atual.',
}

records = []
for c in comments:
    i = int(c['id'])
    target = next((k for k, v in groups.items() if i in v), 'Revisao textual do corpo')
    if i in PENDENTE:
        status, note = 'Pendente', PENDENTE[i]
    elif i in PARCIAL:
        status, note = 'Parcial', PARCIAL[i]
    elif i in ALTERNATIVA:
        status, note = 'Alternativa por solicitacao do autor', ALTERNATIVA[i]
    elif i in DESCRICAO_CORRIGIDA:
        status, note = 'Descricao corrigida conforme codigo', DESCRICAO_CORRIGIDA[i]
    elif i in ATENDIDO_ESPECIFICO:
        status, note = 'Atendido', ATENDIDO_ESPECIFICO[i]
    else:
        status, note = 'Atendido', 'Verificado no manuscrito revisado (manuscrito.md, revisao de 2026-09-13); conferir com orientador antes da entrega final.'
    records.append(dict(id=i, comentario=c['comment'], ancora=' | '.join(c['anchors']),
                         destino=target, status=status, observacao=note))

with (ROOT / 'matriz_comentarios.csv').open('w', newline='', encoding='utf-8-sig') as f:
    w = csv.DictWriter(f, fieldnames=list(records[0]))
    w.writeheader()
    w.writerows(sorted(records, key=lambda r: r['id']))

print(Counter(r['status'] for r in records))
