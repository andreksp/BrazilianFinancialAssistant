"""Task runner: isolated local tests and research scripts only."""
from pathlib import Path
import os, subprocess, sys
ROOT=Path(__file__).parent
mode=sys.argv[1]
version=sys.argv[2] if len(sys.argv)>2 else 'baseline'
env=os.environ.copy(); env['PYTHONIOENCODING']='utf-8'
env['DATABASE_URL']='sqlite:///'+str(ROOT/(version+'_test.db')).replace('\\','/')
env['CHROMA_DB_PATH']=str(ROOT/(version+'_chroma'))
env['PYTHONPATH']=str(ROOT/version/'backend')
if mode=='tests':
    r=subprocess.run([sys.executable,'-m','pytest','tests','-q','--disable-warnings'],cwd=ROOT/version/'backend',env=env,capture_output=True,text=True,encoding='utf-8')
    (ROOT/(version+'_pytest.txt')).write_text(r.stdout+'\n'+r.stderr,encoding='utf-8'); print(r.stdout[-6000:]);sys.exit(r.returncode)
elif mode=='script':
    subprocess.run([sys.executable,str(ROOT/version)],cwd=ROOT,env=env,check=True)
else: raise ValueError(mode)
