from pathlib import Path
import hashlib, json, shutil, subprocess
from zipfile import ZipFile
from lxml import etree
ROOT=Path(__file__).parent
SOURCE=Path(r'D:\Projects\BrazilianFinancialAssistant')
for version in ['baseline','revised']:
    target=ROOT/version
    if target.exists(): continue
    target.mkdir()
    for name in ['backend','frontend','mcp_server','streamlit_app']:
        shutil.copytree(SOURCE/name,target/name,ignore=shutil.ignore_patterns('node_modules','__pycache__','.pytest_cache','.env','*.db','chroma_data','.angular','dist'))
manifest={str(f.relative_to(ROOT/'baseline')):hashlib.sha256(f.read_bytes()).hexdigest() for f in (ROOT/'baseline').rglob('*') if f.is_file()}
(ROOT/'snapshot.json').write_text(json.dumps({'git_head':subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip(),'files':manifest},indent=2),encoding='utf-8')
original=Path(r'C:\Users\andre\Downloads\Monografia_Assistente_Financeiro_RAG_Derivativos_Emprestimos_final (1).docx')
shutil.copy2(original,ROOT/'original_comentado.docx')
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
with ZipFile(original) as z:
    doc=etree.fromstring(z.read('word/document.xml'))
    comments=[]
    for c in etree.fromstring(z.read('word/comments.xml')):
        cid=c.get('{'+ns['w']+'}id')
        anchors=doc.xpath('//w:p[.//w:commentRangeStart[@w:id="'+cid+'"] or .//w:commentReference[@w:id="'+cid+'"]]',namespaces=ns)
        comments.append({'id':cid,'comment':' '.join(c.xpath('.//w:t/text()',namespaces=ns)),'anchors':[''.join(p.xpath('.//w:t/text()',namespaces=ns)) for p in anchors]})
    (ROOT/'comments.json').write_text(json.dumps(comments,ensure_ascii=False,indent=2),encoding='utf-8')
    (ROOT/'original_text.txt').write_text('\n'.join(''.join(p.xpath('.//w:t/text()',namespaces=ns)) for p in doc.xpath('//w:body/w:p',namespaces=ns)),encoding='utf-8')
print('Snapshot and comments saved:',len(manifest),len(comments))
